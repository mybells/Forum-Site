﻿Public Class Class2
    Inherits Label
    Public Sub New()
        Width = 30
        Height = 30

        Dim image_me As Image
        image_me = My.Resources.Resource2.grass '草坪
        Image = image_me




    End Sub











End Class

﻿Imports System.Threading.Thread

Public Class Form1
    Public left_image, right_image, up_image, down_image As Image '我方坦克，上下左右图片
    Public walls_image, symbol11_image, symbol22_image, symbo333_image, symbo444_image As Bitmap 'WALL，英基地图片
    Public bomb_symbol_1, bomb_symbol_2, bomb_symbol_3, bomb_symbol_4 As Bitmap '炸毁—英基地图片

    Public grass_image, water_image, steels_image As Bitmap
    Public born1_image, born2_image, born3_image, born4_image As Bitmap '敌方坦克出场时绘画的星形图片

    Public bullet_image, bullet2_image, bullet3_image As Image '我方子弹图片
    Public enemy_boom_image1, enemy_boom_image2, enemy_boom_image3 As Image

    Public enemy_tank(3) As EnemyTank_Class




    Public start_graphic_IM As Integer = 1 '绘初始化图片
    Public 加载炸图片主机 As Integer = 0

    Public x1, y1 As Integer
    Public W As Integer = 30
    Public H As Integer = 30
    Public LA_ONE_H As Integer = 60 'lable1的高度主机1P的高度
    Public LA_ONE_W As Integer = 60
    Public LA2_H As Integer = 15

    Public isOne As Boolean = True '我方判断是不是第一次发射子弹
    Public isWall As Boolean = False '我方判断是不是子弹到了WALL了
    Public LA2_W As Integer = 15

    Public c_col As Integer = 32 '列长度
    Public c_row As Integer = 22 '行长度
    Public m_map(20, 31) As Integer
    Public move_type As move_UpType = move_UpType.move_UpType
    Public temp_Direction_type As temp_DirectionType = temp_DirectionType.temp_UpType
    Public 主机是否炸毁 As Boolean = False

   



    Public Enum temp_DirectionType
        temp_LeftType
        temp_RightType
        temp_UpType
        temp_DownType
    End Enum

    Public Enum move_UpType
        move_LeftType
        move_RightType
        move_UpType
        move_DownType

    End Enum



    Private Sub Form1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp

        Select Case e.KeyCode
            Case Keys.J, Keys.K, Keys.L, Keys.I

                If Timer3.Enabled = True Then
                    Timer3.Enabled = False

                End If

            Case Else

                Exit Sub


        End Select



    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        '  Me.Width = PictureBox1.Width + 10
        ' Me.Height = 710
        PictureBox1.Width = 960
        PictureBox1.Height = 22 * 30
        PictureBox1.Location = New Point(0, 0)
        ' dd = Image.FromFile("C:\imge\1.gif")
        ' Dim sf As New EnemyTank_Class()
        PictureBox1.BackColor = Color.Black
        up_image = My.Resources.Resource1.u
        left_image = My.Resources.Resource1.l
        right_image = My.Resources.Resource1.r
        down_image = My.Resources.Resource1.d
        bullet_image = My.Resources.Resource2.bullet
        bullet2_image = My.Resources.Resource2.bullet2
        bullet3_image = My.Resources.Resource2.blast3
        walls_image = CType(My.Resources.Resource2.walls, Bitmap)

        born1_image = My.Resources.Resource1.born1
        born2_image = My.Resources.Resource1.born2
        born3_image = My.Resources.Resource1.born3
        born4_image = My.Resources.Resource1.born4






        symbol11_image = CType(My.Resources.Resource2.q4, Bitmap) '基地
        symbol22_image = CType(My.Resources.Resource2.q5, Bitmap)
        symbo333_image = CType(My.Resources.Resource2.q6, Bitmap)
        symbo444_image = CType(My.Resources.Resource2.q7, Bitmap)

        bomb_symbol_1 = CType(My.Resources.Resource2.z4, Bitmap) '炸毁英基地
        bomb_symbol_2 = CType(My.Resources.Resource2.z5, Bitmap) '炸毁英基地
        bomb_symbol_3 = CType(My.Resources.Resource2.z6, Bitmap) '炸毁英基地
        bomb_symbol_4 = CType(My.Resources.Resource2.z7, Bitmap) '炸毁英基地





        grass_image = CType(My.Resources.Resource2.grass, Bitmap) '草坪
        water_image = CType(My.Resources.Resource2.water, Bitmap) '水
        steels_image = CType(My.Resources.Resource2.steel, Bitmap) '钻砖


        enemy_boom_image1 = My.Resources.Resource2.blast5
        enemy_boom_image2 = My.Resources.Resource2.blast6
        enemy_boom_image3 = My.Resources.Resource2.blast7




        init()
        m_map = {{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1},
{1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1},
{-1, -1, -1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1},
{-1, -1, -1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 2, 2, 1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1},
{1, 1, 1, -1, -1, 2, 2, 1, -1, -1, 1, 1, 1, -1, -1, 2, 2, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1},
{1, 1, 1, -1, -1, 1, 1, 1, -1, 1, 3, 3, 1, -1, -1, 3, 3, 1, -1, -1, 1, 1, 1, -1, -1, 1, 2, 2, -1, -1, 1, 1},
{1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 3, 3, 1, -1, -1, 3, 3, 1, -1, -1, 1, 1, 1, -1, -1, 1, 2, 2, -1, -1, 1, 1},
{1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1},
{1, 1, 1, -2, -2, 1, 1, 1, -1, -1, 1, 1, 1, -2, -2, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1},
{1, 1, 1, -2, -2, 1, 1, 1, -1, -1, 1, 1, 1, -2, -2, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1},
{1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 2, 2, 2, 1, -1, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 4, 5, 2, -1, -1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 6, 7, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}
}




        For i = 0 To m_map.GetLength(0) - 1

            For j = 0 To m_map.GetLength(1) - 1
                If m_map(i, j) = -2 Then
                    Dim h_lableTemp As New Class2()
                    h_lableTemp.Parent = PictureBox1
                    h_lableTemp.Location = New Point(j * W, i * H)
                    h_lableTemp.Visible = True

                End If


            Next
        Next

       
        Label4.Parent = PictureBox1
        Label5.Parent = PictureBox1
        Label6.Parent = PictureBox1
        Label7.Parent = PictureBox1



        Label2.Parent = PictureBox1
        Label1.Parent = PictureBox1
        x1 = 10 * 30
        y1 = 20 * 30
        Label1.Location = New Point(x1, y1)
        Label1.Image = up_image
        Label2.Image = bullet_image

        Label4.Image = bullet_image
        Label5.Image = bullet_image
        Label6.Image = bullet_image
        Label7.Image = bullet_image



        PictureBox2.Parent = PictureBox1
        PictureBox3.Parent = PictureBox1
        PictureBox4.Parent = PictureBox1
        PictureBox5.Parent = PictureBox1
        PictureBox6.Parent = PictureBox1

        PictureBox2.Location = New Point(0, 0)
        PictureBox3.Location = New Point(300, 0)
        PictureBox4.Location = New Point(600, 0)
        PictureBox5.Location = New Point(900, 0)

        PictureBox6.Location = New Point(0, 0)
        PictureBox6.Hide()

        Timer2.Enabled = True


        For j = 0 To 3
            enemy_tank(j) = New EnemyTank_Class()

        Next
        Label2.Hide()
        Label4.Hide()
        Label5.Hide()
        Label6.Hide()
        Label7.Hide()

    End Sub



    Private Sub init()
        For i = 0 To m_map.GetLength(0) - 1
            For J = 0 To m_map.GetLength(1) - 1

                m_map(i, J) = -1
            Next

        Next


    End Sub


    Private Sub beginGame()
        Dim g As Graphics = get_Graphic()


        For i = 0 To m_map.GetLength(0) - 1

            For j = 0 To m_map.GetLength(1) - 1
                Select Case m_map(i, j)
                    Case 1
                        g.DrawImage(walls_image, j * W, i * H, W, H) '砖
                    Case 2
                        g.DrawImage(steels_image, j * W, i * H, W, H) '砧石
                    Case 3
                        g.DrawImage(water_image, j * W, i * H, W, H) '水地
                    Case 4
                        g.DrawImage(symbol11_image, j * W, i * H, W, H) 'BOSS

                    Case 5
                        g.DrawImage(symbol22_image, j * W, i * H, W, H) 'BOSS

                    Case 6
                        g.DrawImage(symbo333_image, j * W, i * H, W, H) 'BOSS
                    Case 7
                        g.DrawImage(symbo444_image, j * W, i * H, W, H) 'BOSS

                    Case -1
                        ClearSelectedBlock(j * W, i * W, g) '无东西



                        'Case -2
                        ' g.DrawImage(grass_image, j * W, i * H, W, H) '草地

                End Select


            Next

        Next
        ' g.DrawImage(symbol11_image, PictureBox1.Width \ 2 - W, 23 * H, W, H)
        'g.DrawImage(symbol22_image, PictureBox1.Width \ 2 - W, 24 * H, W, H)

    End Sub









    Private Function get_Graphic() As Graphics


        Dim bmp As Bitmap
        bmp = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        PictureBox1.Image = bmp
        Dim g As Graphics = Graphics.FromImage(PictureBox1.Image)
        Return g
    End Function





    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Dim left_key, right_key, up_key, down_key, bullet_key As Char

        left_key = Microsoft.VisualBasic.Chr(Keys.J)
        right_key = Microsoft.VisualBasic.Chr(Keys.L)
        up_key = Microsoft.VisualBasic.Chr(Keys.I)
        down_key = Microsoft.VisualBasic.Chr(Keys.K)

        bullet_key = Microsoft.VisualBasic.Chr(Keys.F)
        x1 = Label1.Left
        y1 = Label1.Top


        If 主机是否炸毁 = False Then


            Select Case e.KeyChar

                Case left_key
                    '左边###############################################################
                    Label1.Image = left_image
                    move_type = move_UpType.move_LeftType
                    If x1 = 0 Then
                        Exit Sub
                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top Then

                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top + 30 Then


                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top - 30 Then


                            Exit Sub
                        End If


                    Next


                    Timer3.Enabled = True


                Case right_key
                    '右边################################################################################
                    Label1.Image = right_image
                    move_type = move_UpType.move_RightType

                    If x1 >= PictureBox1.Width - Label1.Width Then
                        Exit Sub

                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top Then

                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top + 30 Then

                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top - 30 Then

                            Exit Sub
                        End If





                    Next




                    Timer3.Enabled = True




                Case up_key
                    '上边##########################################################################
                    Label1.Image = up_image
                    move_type = move_UpType.move_UpType
                    If y1 = 0 Then

                        Exit Sub

                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left And enemy_tank(i).Top = Label1.Top - 60 Then
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = Label1.Left + 30 And enemy_tank(i).Top = Label1.Top - 60 Then
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = Label1.Left - 30 And enemy_tank(i).Top = Label1.Top - 60 Then
                            Exit Sub
                        End If





                    Next













                    Timer3.Enabled = True





                Case down_key
                    '下边#############################################################################
                    Label1.Image = down_image
                    move_type = move_UpType.move_DownType
                    If y1 >= (PictureBox1.Height - Label1.Height) Then

                        Exit Sub

                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left And enemy_tank(i).Top = Label1.Top + 60 Then
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = Label1.Left + 30 And enemy_tank(i).Top = Label1.Top + 60 Then
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left - 30 And enemy_tank(i).Top = Label1.Top + 60 Then
                            Exit Sub
                        End If





                    Next



                    Timer3.Enabled = True



                Case bullet_key
                    Timer1.Enabled = True




            End Select
        End If
    End Sub















    Private Function is_up(ByVal x As Integer, ByVal y As Integer, ByVal LA_one As Label) As Boolean
        '___________________________________________________________________________________________________左边

        Dim tempX, tempY As Integer
        tempX = m_map((y - H) \ H, (x + W) \ W)
        tempY = m_map((y - H) \ H, x \ W)
        If tempX < 0 And tempY < 0 Then
            LA_one.Location = New Point(x, y - H)

            Return True
        Else
            Return False

        End If

    End Function

    Private Function is_down(ByVal x As Integer, ByVal y As Integer, ByVal LA_one As Label) As Boolean


        Dim tempX, tempY As Integer
        tempX = m_map((y + LA_one.Height) \ H, x \ W)
        tempY = m_map((y + LA_one.Height) \ H, (x + 30) \ W)

        If tempX < 0 And tempY < 0 Then
            LA_one.Location = New Point(x, y + 30)

            Return True
        Else
            Return False

        End If

    End Function






    Private Function is_left(ByVal x As Integer, ByVal y As Integer, ByVal LA_one As Label) As Boolean
        Dim tempX, tempY As Integer



        tempX = m_map(y \ H, (x - W) \ W)
        tempY = m_map((y + H) \ H, (x - 30) \ W)

        If tempX < 0 And tempY < 0 Then
            LA_one.Location = New Point(x - 30, y)

            Return True

        Else
            Return False
        End If










    End Function



    Private Function is_right(ByVal x As Integer, ByVal y As Integer, ByVal LA_one As Label) As Boolean
        Dim tempX, tempY As Integer



        tempX = m_map(y \ H, (x + 60) \ W)
        tempY = m_map((y + H) \ H, (x + LA_one.Width) \ W)

        If tempX < 0 And tempY < 0 Then
            LA_one.Location = New Point(x + 30, y)

            Return True

        Else
            Return False
        End If






    End Function


    Private Function is_bullet_key(ByVal x As Integer, ByVal y As Integer) As Boolean

        ' Dim tempX, tempY As Integer

        ' tempX = x \ 2 - 7
        ' tempY = y




        Return False
    End Function





    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        Dim tempX, tempY As Integer
        tempX = Label1.Left
        tempY = Label1.Top

        ' MsgBox("FFF")

        If isWall Then
            '用于处理子弹在WALL，上时的清除
            Select Case temp_Direction_type


                Case temp_DirectionType.temp_UpType
                    Label2.Hide()
                    Label2.Width = 15
                    Label2.Height = 15

                    isWall = False
                    Timer1.Enabled = False
                    Exit Sub

                Case temp_DirectionType.temp_DownType
                    Label2.Hide()
                    Label2.Width = 15
                    Label2.Height = 15

                    isWall = False
                    Timer1.Enabled = False
                    Exit Sub
                Case temp_DirectionType.temp_LeftType
                    Label2.Hide()
                    Label2.Width = 15
                    Label2.Height = 15

                    isWall = False
                    Timer1.Enabled = False
                    Exit Sub
                Case temp_DirectionType.temp_RightType
                    Label2.Hide()
                    Label2.Width = 15
                    Label2.Height = 15

                    isWall = False
                    Timer1.Enabled = False
                    Exit Sub


            End Select





        End If


        If isOne Then
            '第一次执行
            Select Case move_type
                Case move_UpType.move_UpType
                    '#############################################################################子弹向上

                    '当子弹的方向，向上时
                    If tempY = 0 Then
                        '当坦克的Y等于O时，就是最顶了
                        Label2.Show()
                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + Label1.Width \ 2 - 14, 0)

                        temp_Direction_type = temp_DirectionType.temp_UpType
                        isWall = True
                        Exit Sub
                    End If


                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left And enemy_tank(i).Top = Label1.Top - 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + 15, tempY)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select





                            End If
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = Label1.Left + 30 And enemy_tank(i).Top = Label1.Top - 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + 15, tempY)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select

                            End If
                            Exit Sub

                        End If

                        If enemy_tank(i).Left = Label1.Left - 30 And enemy_tank(i).Top = Label1.Top - 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + 22, tempY)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub

                        End If





                    Next

                    '判断主机是不是炸毁，如果是就不用好子弹退出
                    If Label1.Visible = False Then

                        isOne = True
                        isWall = True
                        Timer1.Enabled = False
                        Exit Sub


                    End If
                    Dim temp_m_map_down_one1 As Integer = m_map((tempY - 30) \ H, tempX \ W)
                    Dim temp_m_map_down_two2 As Integer = m_map((tempY - 30) \ H, (tempX + W) \ W)

                    '以下是，第一次，子弹准备发射
                    If temp_m_map_down_one1 = -1 And temp_m_map_down_two2 = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub


                    ElseIf temp_m_map_down_one1 = 1 And temp_m_map_down_two2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1
                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1

                        ClearSelectedBlock(tempX, tempY - H, g)
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = 1 And temp_m_map_down_two2 = -1 Then
                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1


                        ClearSelectedBlock(tempX, tempY - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = -1 And temp_m_map_down_two2 = 1 Then
                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)

                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = 1 And temp_m_map_down_two2 = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1


                        ClearSelectedBlock(tempX, tempY - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = -2 And temp_m_map_down_two2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)

                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = -2 And temp_m_map_down_two2 = -2 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = -2 And temp_m_map_down_two2 = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub


                    ElseIf temp_m_map_down_one1 And temp_m_map_down_two2 = -2 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = 2 And temp_m_map_down_two2 = 2 Then



                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY)

                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = 2 And temp_m_map_down_two2 = -1 Then



                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY)

                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = -1 And temp_m_map_down_two2 = 2 Then



                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY)

                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = 2 And temp_m_map_down_two2 = 1 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY)
                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = 1 And temp_m_map_down_two2 = 2 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY)
                        m_map((tempY - 30) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = 3 And temp_m_map_down_two2 = 3 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = 3 And temp_m_map_down_two2 = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = -1 And temp_m_map_down_two2 = 3 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY - 15)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_UpType
                        Exit Sub

                    ElseIf temp_m_map_down_one1 = 1 And temp_m_map_down_two2 = 3 Then
                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1


                        ClearSelectedBlock(tempX, tempY - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf temp_m_map_down_one1 = 3 And temp_m_map_down_two2 = 1 Then
                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY - H)

                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    End If

                Case move_UpType.move_DownType
                    '子弹未发射向下############################################################################子弹向下第一次发


                    If tempY = PictureBox1.Height - LA_ONE_H Then

                        '当坦克的Y等于PictureBox1.height时，就是最下方了
                        Label2.Visible = True

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + Label1.Width \ 2 - 14, PictureBox1.Height - 10)

                        temp_Direction_type = temp_DirectionType.temp_DownType
                        isWall = True
                        Exit Sub
                    End If


                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left And enemy_tank(i).Top = Label1.Top + 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(tempX + 15, tempY + 60)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If



                        If enemy_tank(i).Left = Label1.Left + 30 And enemy_tank(i).Top = Label1.Top + 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(tempX + 15, tempY + 60)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left - 30 And enemy_tank(i).Top = Label1.Top + 60 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(tempX + 15, tempY + 60)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If

                    Next



                    '判断主机是不是炸毁，如果是就不用好子弹退出
                    If Label1.Visible = False Then

                        isOne = True
                        isWall = True
                        Timer1.Enabled = False
                        Exit Sub


                    End If

                    Dim LA_ONE_DOWN_m_map_1 As Integer = m_map((tempY + LA_ONE_H) \ H, tempX \ W)
                    Dim LA_ONE_DOWN_m_map_2 As Integer = m_map((tempY + LA_ONE_H) \ H, (tempX + 30) \ W)

                    If LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1

                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub



                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = -2 Then


                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub



                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = 2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 2 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        isOne = True
                        isWall = True
                        Exit Sub



                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = 1 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 2 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub
                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + 22), tempY + LA_ONE_H)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_DownType
                        Exit Sub
                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 3 Then


                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    End If



                Case move_UpType.move_LeftType
                    '子弹未发射向左#####################################################################################
                    If tempX <= 0 Then
                        Label2.Visible = True

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 3, tempY + 15)

                        temp_Direction_type = move_UpType.move_LeftType
                        isWall = True
                        Exit Sub
                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top Then



                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top + 30 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub


                        End If
                        If enemy_tank(i).Left = Label1.Left - 60 And enemy_tank(i).Top = Label1.Top - 30 Then
                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub


                        End If


                    Next


                    '判断主机是不是炸毁，如果是就不用好子弹退出
                    If Label1.Visible = False Then

                        isOne = True
                        isWall = True
                        Timer1.Enabled = False
                        Exit Sub


                    End If

                    Dim left_m_map_one As Integer = m_map(tempY \ H, (tempX - W) \ W)
                    Dim left_m_map_two As Integer = m_map((tempY + H) \ H, (tempX - W) \ W)

                    If m_map(tempY \ H, (tempX - W) \ W) = -1 And m_map((tempY + H) \ H, (tempX - W) \ W) = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1
                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1

                        ClearSelectedBlock(tempX - W, tempY, g)
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf left_m_map_one = -1 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = -2 And left_m_map_two = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub
                    ElseIf left_m_map_one = -2 And left_m_map_two = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = -1 And left_m_map_two = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub


                    ElseIf left_m_map_one = 1 And left_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf left_m_map_one = -2 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 3 And left_m_map_two = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub


                    ElseIf left_m_map_one = 3 And left_m_map_two = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = -1 And left_m_map_two = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15
                        isOne = False
                        temp_Direction_type = move_UpType.move_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf left_m_map_one = 3 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 2 And left_m_map_two = 2 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image
                        Label2.Location = New Point(tempX - 5, tempY + 15)


                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 2 And left_m_map_two = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image
                        Label2.Location = New Point(tempX - 5, tempY + 15)


                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = -1 And left_m_map_two = 2 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image
                        Label2.Location = New Point(tempX - 5, tempY + 15)


                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 2 And left_m_map_two = 1 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 5, tempY + 15)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = 2 Then
                        Dim g As Graphics = get_Graphic()


                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX - 5, tempY + 15)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    End If





                Case move_UpType.move_RightType
                    '子弹未发射向右#################################################################################

                    If tempX >= PictureBox1.Width - Label1.Width Then
                        Label2.Visible = True

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(PictureBox1.Width - LA2_W, tempY + 15)
                        Me.Text = PictureBox1.Width
                        temp_Direction_type = move_UpType.move_RightType
                        isWall = True
                        Exit Sub
                    End If

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top Then


                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top + 30 Then

                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label1.Left + 60 And enemy_tank(i).Top = Label1.Top - 30 Then

                            If Label2.Visible = False Then
                                Label2.Visible = True
                            End If


                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image

                            Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)


                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If





                    Next
                    '判断主机是不是炸毁，如果是就不用好子弹退出
                    If Label1.Visible = False Then

                        isOne = True
                        isWall = True
                        Timer1.Enabled = False
                        Exit Sub


                    End If


                    Dim LA_TWO_m_map_one As Integer = m_map(tempY \ H, (tempX + LA_ONE_W) \ W)
                    Dim LA_TWO_m_map_two As Integer = m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W)

                    If m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1 And m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1 Then
                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType

                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1
                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1

                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)
                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub
                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub
                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = -2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub
                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = -1 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 3 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If
                        Label2.Image = bullet_image
                        Label2.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        isOne = False
                        temp_Direction_type = temp_DirectionType.temp_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = 2 Then

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1

                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)
                        Refresh()
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        If Label2.Visible = False Then
                            Label2.Visible = True
                        End If


                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(tempX + LA_ONE_W, tempY + 15)
                        Refresh()
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub



                    End If

                Case Else
                    Timer1.Enabled = False
                    Exit Sub
            End Select



            '以下是子弹已经发射向上，只判断子弹的坐标########################################################################
            '以下是子弹已经发射向上，只判断子弹的坐标########################################################################

        Else
            Label2.Width = 15
            Label2.Height = 15
            Select Case temp_Direction_type
                Case temp_DirectionType.temp_UpType
                    Dim L2_x As Integer = Label2.Left
                    Dim L2_y As Integer = Label2.Top


                    For i = 0 To 3

                        If enemy_tank(i).Left = Label2.Left - 22 And enemy_tank(i).Top = Label2.Top - 75 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top - 15)
                            If enemy_tank(i).rt_count = 2 Then

                                enemy_tank(i).改变敌机图片()


                            Else
                                Select Case i
                                    Case 0



                                        
                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1
                                        
                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2
                                      
                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3
                                       
                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select

                            End If
                            isOne = True
                            isWall = True

                            Exit Sub
                        End If



                        If enemy_tank(i).Left = Label2.Left - 22 - 30 And enemy_tank(i).Top = Label2.Top - 75 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top - 15)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()

                    
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True
                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select




                            End If
                            Exit Sub
                        End If








                        If enemy_tank(i).Left = Label2.Left + 8 And enemy_tank(i).Top = Label2.Top - 75 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top - 15)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                               
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                       
                                        Timer12.Enabled = True
                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If


                    Next
                  





                    If L2_y <= 30 Then
                        '当Y=30时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image
                        Label2.Location = New Point((L2_x - 10), 0)
                        isOne = True
                        isWall = True
                        Exit Sub
                    End If

                 
                   

                    '当子弹正常飞行时，每次向上加30高
                    If m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y - H)
                        Exit Sub


                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1
                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1

                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)
                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left - 12, Label2.Top)
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left - 12, Label2.Top)
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left - 12, Label2.Top)
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left - 12, Label2.Top)
                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left - 12, Label2.Top)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1
                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then
                        Label2.Location = New Point(L2_x, L2_y - H)

                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        isOne = True
                        isWall = True

                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(Label2.Left, Label2.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    End If







                 

                Case temp_DirectionType.temp_DownType
                    '向下——子弹已发射######################################################################################子弹已发射
                    Dim L2_x As Integer = Label2.Left
                    Dim L2_y As Integer = Label2.Top


                    For i = 0 To 3

                        If enemy_tank(i).Left = Label2.Left - 22 And enemy_tank(i).Top = Label2.Top + 30 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top + 30)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()

                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select













                            End If






                            Exit Sub
                        End If




                        If enemy_tank(i).Left = Label2.Left - 22 - 30 And enemy_tank(i).Top = Label2.Top + 30 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top + 30)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select











                            End If








                            Exit Sub
                        End If





                        If enemy_tank(i).Left = Label2.Left + 8 And enemy_tank(i).Top = Label2.Top + 30 Then
                            Label2.Width = 30
                            Label2.Height = 15
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left - 7, Label2.Top + 30)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()


                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select



                            End If



                            Exit Sub
                        End If


                    Next



                    If L2_y >= PictureBox1.Height - H Then
                        '当子弹在最下边界，时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image
                        Label2.Location = New Point((L2_x - 10), PictureBox1.Height - 5)
                        isOne = True
                        isWall = True
                        Exit Sub
                    End If




                    If m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1
                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1

                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y + H)

                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then
                        Label2.Location = New Point(L2_x, L2_y + H)
                        Exit Sub



                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then



                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 30
                        Label2.Height = 15
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub



                    End If

                Case temp_DirectionType.temp_LeftType
                    ' 向左子弹已发射########################################################################################
                    Dim L2_X As Integer = Label2.Left
                    Dim L2_Y As Integer = Label2.Top

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label2.Left - 75 And enemy_tank(i).Top = Label2.Top - 22 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 15, Label2.Top - 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select


                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label2.Left - 75 And enemy_tank(i).Top = Label2.Top - 22 - 30 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 15, Label2.Top - 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else

                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select






                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label2.Left - 75 And enemy_tank(i).Top = Label2.Top + 8 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 15, Label2.Top + 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else


                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select




                            End If
                            Exit Sub
                        End If


                    Next




                    If L2_X <= 0 Then
                        '当子弹在最下边界，时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image
                        Label2.Location = New Point(0, L2_Y - 5)
                        isOne = True
                        isWall = True
                        Exit Sub
                    End If
                    Dim L2_LEFT_m_map_one = m_map((L2_Y - 22) \ H, (L2_X - 30) \ W)
                    Dim L2_LEFT_m_map_two = m_map((L2_Y + 8) \ H, (L2_X - 30) \ W)

                    If m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub



                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1
                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1

                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)
                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub
                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = -2 And L2_LEFT_m_map_two = -2 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub
                    ElseIf L2_LEFT_m_map_one = -2 And L2_LEFT_m_map_two = -1 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub
                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = -2 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = -2 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub



                    ElseIf L2_LEFT_m_map_one = 3 And L2_LEFT_m_map_two = 3 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub
                    ElseIf L2_LEFT_m_map_one = 3 And L2_LEFT_m_map_two = -1 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub
                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = 3 Then
                        Label2.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = 3 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1
                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_X - 15, L2_Y - 7)
                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    End If

                Case temp_DirectionType.temp_RightType
                    '向右子弹已发射###############################################################################
                    Dim L2_x As Integer = Label2.Left
                    Dim L2_y As Integer = Label2.Top

                    For i = 0 To 3

                        If enemy_tank(i).Left = Label2.Left + 30 And enemy_tank(i).Top = Label2.Top - 22 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 30, Label2.Top - 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select



                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label2.Left + 30 And enemy_tank(i).Top = Label2.Top - 22 - 30 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 30, Label2.Top - 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = Label2.Left + 30 And enemy_tank(i).Top = Label2.Top + 8 Then
                            Label2.Width = 15
                            Label2.Height = 30
                            Label2.Image = bullet2_image
                            Label2.Location = New Point(Label2.Left + 30, Label2.Top + 7)
                            isOne = True
                            isWall = True
                            If enemy_tank(i).rt_count = 2 Then
                                enemy_tank(i).改变敌机图片()
                            Else
                                Select Case i
                                    Case 0




                                        Timer4.Stop()
                                        Timer4.Enabled = False
                                        PictureBox2.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer12.Enabled = True

                                    Case 1

                                        Timer6.Stop()
                                        Timer6.Enabled = False
                                        PictureBox3.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer13.Enabled = True
                                    Case 2

                                        Timer8.Stop()
                                        Timer8.Enabled = False
                                        PictureBox4.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer14.Enabled = True

                                    Case 3

                                        Timer10.Stop()
                                        Timer10.Enabled = False
                                        PictureBox5.Location = New Point(enemy_tank(i).Left - 10, enemy_tank(i).Top - 10)
                                        enemy_tank(i).Hide()
                                        enemy_tank(i).Location = New Point(-90, -90)
                                        Timer15.Enabled = True
                                End Select
                            End If
                            Exit Sub
                        End If


                    Next





















                    If L2_x >= PictureBox1.Width - 30 Then
                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image
                        Label2.Location = New Point(PictureBox1.Width - LA2_W, L2_y - 7)
                        isOne = True
                        isWall = True
                        Exit Sub


                    End If
                    Dim LA_right_m_map_one As Integer = m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W)
                    Dim LA_right_m_map_two As Integer = m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W)

                    If m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1 And m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1
                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1

                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)
                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = -2 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = -1 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = -2 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub


                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = 3 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = -1 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 3 Then

                        Label2.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub


                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)

                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub






                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        Label2.Width = 15
                        Label2.Height = 30
                        Label2.Image = bullet2_image

                        Label2.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)


                        beginGame()
                        isOne = True
                        isWall = True
                        Exit Sub




                    End If


            End Select







        End If








    End Sub





    Private Sub ClearSelectedBlock(ByVal x As Integer, ByVal y As Integer, ByVal g As Graphics)
        '清除选中方块
        Dim myBrush As SolidBrush = New SolidBrush(PictureBox1.BackColor)  '定义背景色画刷
        Dim b1 As Rectangle = New Rectangle(x, y, W, H)
        g.FillRectangle(myBrush, b1)
        '
    End Sub











    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

        beginGame()
    End Sub


    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Graphics_Start_Image()
    End Sub





    Private Sub Graphics_Start_Image()

        Select Case start_graphic_IM

            Case 1
                PictureBox2.Image = born1_image
                PictureBox3.Image = born1_image
                PictureBox4.Image = born1_image
                PictureBox5.Image = born1_image


            Case 2


                PictureBox2.Image = born2_image
                PictureBox3.Image = born2_image
                PictureBox4.Image = born2_image
                PictureBox5.Image = born2_image


            Case 3

                PictureBox2.Image = born3_image
                PictureBox3.Image = born3_image
                PictureBox4.Image = born3_image
                PictureBox5.Image = born3_image


            Case 4

                PictureBox2.Image = born4_image
                PictureBox3.Image = born4_image
                PictureBox4.Image = born4_image
                PictureBox5.Image = born4_image

            Case 5

                PictureBox2.Hide()
                PictureBox3.Hide()
                PictureBox4.Hide()
                PictureBox5.Hide()
                For i = 0 To 3
                    enemy_tank(i).Parent = PictureBox1
                    enemy_tank(i).Location = New Point(i * 300, 0)
                Next


                Timer2.Enabled = False
                ' enemy_tank(0).Location = New Point(540, 630)

                Timer4.Enabled = True
                Timer6.Enabled = True
                Timer8.Enabled = True
                Timer10.Enabled = True
        End Select
        start_graphic_IM = (start_graphic_IM + 1)

    End Sub


    Private Function enemy_AI(ByVal enemy_Objer As EnemyTank_Class, ByVal ti As Timer) As Boolean
        Dim Ex, Ey As Integer
        Ex = enemy_Objer.Left
        Ey = enemy_Objer.Top
        Dim temp_rt As New Random()

        If enemy_Objer.isTimeSet = False Then
            '令这个判断只执行一次
            If enemy_Objer.rt_count = 4 Then
                '判断是什么色的敌机如果是绿色加快那个就要调一下时间
                ti.Interval = 100
                ' enemy_Objer.isTimeSet = True
            End If



            Select Case temp_rt.Next(1, 5)
                '产生敌方坦克，方向的随机数1左，2右，3上，4下


                Case 1
                    '左边#########################################################################################################
                    '如果随机返回的是1就是加入左边坦克图片
                    enemy_Objer.Image = enemy_Objer.EE_left_image
                    enemy_Objer.E_TYPE = EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_LeftType
                    If Ex = 0 Then
                        Return False
                        Exit Function
                    End If
                    For i = 0 To 3
                        If enemy_tank(i).Equals(enemy_Objer) = False Then
                            If enemy_tank(i).Left = enemy_Objer.Left - 60 And enemy_tank(i).Top = enemy_Objer.Top Then
                                Return False
                                Exit Function
                            End If
                            If enemy_tank(i).Left = enemy_Objer.Left - 60 And enemy_tank(i).Top = enemy_Objer.Top + 30 Then

                                Return False
                                Exit Function
                            End If
                            If enemy_tank(i).Left = enemy_Objer.Left - 60 And enemy_tank(i).Top = enemy_Objer.Top - 30 Then

                                Return False
                                Exit Function
                            End If

                        End If
                    Next

                    If Label1.Left = enemy_Objer.Left - 60 And Label1.Top = enemy_Objer.Top Then
                        Return False
                        Exit Function
                    End If
                    If Label1.Left = enemy_Objer.Left - 60 And Label1.Top = enemy_Objer.Top + 30 Then

                        Return False
                        Exit Function
                    End If
                    If Label1.Left = enemy_Objer.Left - 60 And Label1.Top = enemy_Objer.Top - 30 Then

                        Return False
                        Exit Function
                    End If





                    '判断前方有无阻碍物
                    If enemy_is_left(Ex, Ey, enemy_Objer) = False Then

                        Return False
                        Exit Function
                    Else
                        Return True
                    End If




                Case 2
                    '右边#########################################################################################################
                    enemy_Objer.Image = enemy_Objer.EE_rightT_image
                    enemy_Objer.E_TYPE = EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_RightType
                    If Ex = PictureBox1.Width - enemy_Objer.Width Then
                        Return False

                    End If
                    For i = 0 To 3
                        If enemy_tank(i).Equals(enemy_Objer) = False Then
                            If enemy_tank(i).Left = enemy_Objer.Left + 60 And enemy_tank(i).Top = enemy_Objer.Top Then

                                Return False
                            End If
                            If enemy_tank(i).Left = enemy_Objer.Left + 60 And enemy_tank(i).Top = enemy_Objer.Top + 30 Then

                                Return False
                            End If
                            If enemy_tank(i).Left = enemy_Objer.Left + 60 And enemy_tank(i).Top = enemy_Objer.Top - 30 Then

                                Return False
                            End If



                        End If

                    Next


                    If Label1.Left = enemy_Objer.Left + 60 And Label1.Top = enemy_Objer.Top Then

                        Return False
                    End If
                    If Label1.Left = enemy_Objer.Left + 60 And Label1.Top = enemy_Objer.Top + 30 Then

                        Return False
                    End If
                    If Label1.Left = enemy_Objer.Left + 60 And Label1.Top = enemy_Objer.Top - 30 Then

                        Return False
                    End If














                    If enemy_is_right(Ex, Ey, enemy_Objer) = False Then
                        Return False
                    Else
                        Return True
                    End If














                Case 3
                    '上边#########################################################################################################
                    enemy_Objer.Image = enemy_Objer.EE_up_image
                    enemy_Objer.E_TYPE = EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_UpType
                    If Ey = 0 Then

                        Return False

                    End If

                    For i = 0 To 3
                        If enemy_tank(i).Equals(enemy_Objer) = False Then
                            If enemy_tank(i).Left = enemy_Objer.Left And enemy_tank(i).Top = enemy_Objer.Top - 60 Then
                                Return False
                            End If

                            If enemy_tank(i).Left = enemy_Objer.Left + 30 And enemy_tank(i).Top = enemy_Objer.Top - 60 Then
                                Return False
                            End If

                            If enemy_tank(i).Left = enemy_Objer.Left - 30 And enemy_tank(i).Top = enemy_Objer.Top - 60 Then
                                Return False
                            End If



                        End If

                    Next

                    If Label1.Left = enemy_Objer.Left And Label1.Top = enemy_Objer.Top - 60 Then
                        Return False
                    End If

                    If Label1.Left = enemy_Objer.Left + 30 And Label1.Top = enemy_Objer.Top - 60 Then
                        Return False
                    End If

                    If Label1.Left = enemy_Objer.Left - 30 And Label1.Top = enemy_Objer.Top - 60 Then
                        Return False
                    End If



                    If enemy_is_up(Ex, Ey, enemy_Objer) = False Then
                        Return False
                    Else
                        Return True
                    End If










                Case 4
                    '下边#########################################################################################################
                    enemy_Objer.Image = enemy_Objer.EE_down_image
                    enemy_Objer.E_TYPE = EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_DownType
                    If Ey = PictureBox1.Height - enemy_Objer.Height = True Then

                        Return False

                    End If
                    For i = 0 To 3
                        If enemy_tank(i).Equals(enemy_Objer) = False Then
                            If enemy_tank(i).Left = enemy_Objer.Left And enemy_tank(i).Top = enemy_Objer.Top + 60 Then
                                Return False
                            End If

                            If enemy_tank(i).Left = enemy_Objer.Left + 30 And enemy_tank(i).Top = enemy_Objer.Top + 60 Then
                                Return False
                            End If
                            If enemy_tank(i).Left = enemy_Objer.Left - 30 And enemy_tank(i).Top = enemy_Objer.Top + 60 Then
                                Return False
                            End If



                        End If

                    Next

                    If Label1.Left = enemy_Objer.Left And Label1.Top = enemy_Objer.Top + 60 Then
                        Return False
                    End If

                    If Label1.Left = enemy_Objer.Left + 30 And Label1.Top = enemy_Objer.Top + 60 Then
                        Return False
                    End If
                    If Label1.Left = enemy_Objer.Left - 30 And Label1.Top = enemy_Objer.Top + 60 Then
                        Return False
                    End If












                    If enemy_is_down(Ex, Ey, enemy_Objer) = False Then
                        Return False
                    Else
                        Return True
                    End If





            End Select


        Else
            Return False


        End If



        Return True










    End Function



    Private Function enemy_is_down(ByVal x As Integer, ByVal y As Integer, ByVal enemy_Ob As EnemyTank_Class) As Boolean


        Dim count_one, count_teo As Integer
        count_one = m_map((y + enemy_Ob.Height) \ H, x \ W)
        count_teo = m_map((y + enemy_Ob.Height) \ H, (x + W) \ W)


        If count_one < 0 And count_teo < 0 Then
            '如果左边无阻碍物那么

            For i = 0 To ((c_row - y / H - 2) - 1)

                count_one = m_map((y + i * H + 60) \ H, x \ W)
                count_teo = m_map((y + i * H + 60) \ H, (x + W) \ W)
                If count_one > 0 Or count_teo > 0 Then

                    If i >= 10 Then
                        '判断前进方向有无阻碍
                        Dim temp_rt As New Random()
                        If (temp_rt.Next(1, 3)) = 1 Then
                            enemy_Ob.e_direction = 1

                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else

                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If

                    Else
                        '前方无阻碍但步数少于10就直接前进
                        enemy_Ob.e_direction = 1
                        Return True
                    End If

                End If


            Next
            Dim temp2_rt As New Random()
            If (temp2_rt.Next(1, 3)) = 1 Then
                enemy_Ob.e_direction = 1

                Return True '1表示前方无阻碍大于10步，前进到尾

            Else

                enemy_Ob.e_direction = 2
                Return True '表示前方无阻碍大于10步，前进一个随机数

            End If





        Else
            Return False
        End If


    End Function






    Private Function enemy_is_up(ByVal x As Integer, ByVal y As Integer, ByVal enemy_Ob As EnemyTank_Class) As Boolean
        ' MsgBox("kkkk")
        ' If y <= 0 Then
        'Return False
        ' End If



        Dim tempX, tempY As Integer
        tempX = m_map((y - H) \ H, (x + W) \ W)
        tempY = m_map((y - H) \ H, x \ W)



        If tempX < 0 And tempY < 0 Then


            '如果上边无阻碍物那么

            For i = 0 To (y \ H) - 1


                tempX = m_map((y - i * H - H) \ H, (x + W) \ W) '##################################################################
                tempY = m_map((y - i * H - H) \ H, x \ W)
                If tempX > 0 Or tempY > 0 Then
                    If i >= 10 Then
                        '判断前进方向有无阻碍
                        Dim temp_rt As New Random()
                        If (temp_rt.Next(1, 3)) = 1 Then
                            enemy_Ob.e_direction = 1
                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else

                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If

                    Else
                        '前方无阻碍但步数少于10就直接前进
                        enemy_Ob.e_direction = 1
                        Return True
                    End If

                End If


            Next



            Dim temp2_rt As New Random()
            If (temp2_rt.Next(1, 3)) = 1 Then
                enemy_Ob.e_direction = 1

                Return True '1表示前方无阻碍大于10步，前进到尾

            Else

                enemy_Ob.e_direction = 2
                Return True '表示前方无阻碍大于10步，前进一个随机数

            End If


        Else
            Return False

        End If


    End Function










    Private Function enemy_is_right(ByVal x As Integer, ByVal y As Integer, ByVal enemy_Ob As EnemyTank_Class) As Boolean
        Dim tempX, tempY As Integer



        tempX = m_map(y \ H, (x + enemy_Ob.Width) \ W)
        tempY = m_map((y + H) \ H, (x + enemy_Ob.Width) \ W)

        If tempX < 0 And tempY < 0 Then

            For i = 0 To c_col - (x \ 30) - 2 - 1
                tempX = m_map(y \ H, (x + i * W + enemy_Ob.Width) \ W) '))))))))))))))))))))00
                tempY = m_map((y + H) \ H, (x + i * W + enemy_Ob.Width) \ W)

                If tempX > 0 Or tempY > 0 Then
                    If i >= 10 Then

                        '判断前进方向有无阻碍
                        Dim temp_rt As New Random()
                        If (temp_rt.Next(1, 3)) = 1 Then
                            enemy_Ob.e_direction = 1

                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else

                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If

                    Else
                        '前方无阻碍但步数少于10就直接前进
                        enemy_Ob.e_direction = 1
                        Return True
                    End If
                Else
                    If i >= 10 Then
                        'MsgBox(i)
                        '判断前进方向有无阻碍
                        Dim temp_rt As New Random()
                        If (temp_rt.Next(1, 3)) = 1 Then
                            enemy_Ob.e_direction = 1

                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else

                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If


                    End If

                End If


            Next


            Dim temp2_rt As New Random()
            If (temp2_rt.Next(1, 3)) = 1 Then
                enemy_Ob.e_direction = 1

                Return True '1表示前方无阻碍大于10步，前进到尾

            Else

                enemy_Ob.e_direction = 2
                Return True '表示前方无阻碍大于10步，前进一个随机数

            End If

        Else
            enemy_Ob.e_direction = 0
            Return False
        End If






    End Function


    Private Function enemy_is_left(ByVal x As Integer, ByVal y As Integer, ByVal enemy_Ob As EnemyTank_Class) As Boolean
        Dim tempX, tempY As Integer



        tempX = m_map(y \ H, (x - W) \ W)
        tempY = m_map((y + H) \ H, (x - W) \ W)

        If tempX < 0 And tempY < 0 Then
            '如果左边无阻碍物那么

            For i = 0 To (x \ 30) - 1
                tempX = m_map(y \ H, (x - i * W - W) \ W)
                tempY = m_map((y + H) \ H, (x - i * W - W) \ W)
                If tempX > 0 Or tempY > 0 Then
                    If i >= 10 Then
                        '判断前进方向有无阻碍
                        Dim temp_rt As New Random()
                        If (temp_rt.Next(1, 3)) = 1 Then
                            enemy_Ob.e_direction = 1

                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else

                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If

                    Else
                        '前方无阻碍但步数少于10就直接前进
                        enemy_Ob.e_direction = 1
                        Return True

                    End If



                Else
                    If i >= 10 Then

                        'MsgBox(i)
                        '判断前进方向有无阻碍
                        Dim temp4_rt As New Random()
                        If (temp4_rt.Next(1, 3)) = 2 Then
                            enemy_Ob.e_direction = 1

                            Return True '1表示前方无阻碍大于10步，前进到尾

                        Else
                            ' MsgBox("FF")
                            enemy_Ob.e_direction = 2
                            Return True '表示前方无阻碍大于10步，前进一个随机数

                        End If


                    End If

                End If
            Next



            Dim temp2_rt As New Random()
            If (temp2_rt.Next(1, 3)) = 1 Then
                enemy_Ob.e_direction = 1

                Return True '1表示前方无阻碍大于10步，前进到尾

            Else

                enemy_Ob.e_direction = 2
                Return True '表示前方无阻碍大于10步，前进一个随机数

            End If

        Else
            enemy_Ob.e_direction = 0
            Return False
        End If



    End Function









    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        Select Case move_type
            Case move_UpType.move_LeftType

                If is_left(x1, y1, Label1) = False Then
                    Timer3.Enabled = False
                    Exit Sub

                Else
                    Timer3.Enabled = False
                    Exit Sub
                End If



            Case move_UpType.move_RightType

                If is_right(x1, y1, Label1) = False Then
                    Timer3.Enabled = False
                    Exit Sub
                Else
                    Timer3.Enabled = False
                    Exit Sub
                End If

            Case move_UpType.move_UpType


                If is_up(x1, y1, Label1) = False Then
                    Timer3.Enabled = False
                    Exit Sub
                Else
                    Timer3.Enabled = False
                    Exit Sub
                End If

            Case move_UpType.move_DownType

                If is_down(x1, y1, Label1) = False Then
                    Timer3.Enabled = False
                    Exit Sub
                Else
                    Timer3.Enabled = False
                    Exit Sub
                End If


        End Select





    End Sub

    Private Sub Timer4_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer4.Tick
        敌方坦克移动和发射(enemy_tank(0), Timer5, Timer4)

    End Sub





    '敌方子弹

    Private Sub 敌方子弹(ByVal enemy_Obj As EnemyTank_Class, ByVal temp_time As Timer, ByVal temp_LA As Label)
        Dim tempX, tempY As Integer
        tempX = enemy_Obj.Left
        tempY = enemy_Obj.Top
        'enemy_Objer.E_TYPE = EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_UpType

        If enemy_Obj.子弹是否拼撞 Then
            '用于处理子弹在WALL，上时的清除
            Select Case enemy_Obj.E_BUT_TYPE_Direction


                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                    temp_LA.Hide()
                    temp_LA.Width = 15
                    temp_LA.Height = 15

                    enemy_Obj.子弹是否拼撞 = False
                    temp_time.Enabled = False
                    Exit Sub
                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType

                    temp_LA.Hide()
                    temp_LA.Width = 15
                    temp_LA.Height = 15

                    enemy_Obj.子弹是否拼撞 = False
                    temp_time.Enabled = False
                    Exit Sub
                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType

                    temp_LA.Hide()
                    temp_LA.Width = 15
                    temp_LA.Height = 15

                    enemy_Obj.子弹是否拼撞 = False
                    temp_time.Enabled = False
                    Exit Sub

                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                    temp_LA.Hide()
                    temp_LA.Width = 15
                    temp_LA.Height = 15

                    enemy_Obj.子弹是否拼撞 = False

                    temp_time.Enabled = False

                    Exit Sub


            End Select



        End If


        If enemy_Obj.子弹是否第一次发射 Then
            '第一次执行
            Select Case enemy_Obj.E_TYPE
                Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_UpType

                    '当子弹的方向，向上时
                    If tempY = 0 Then
                        '当坦克的Y等于O时，就是最顶了
                        temp_LA.Show()
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + Label1.Width \ 2 - 14, 0)

                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If
                    '以下是，第一次，子弹准备发射
                    If enemy_Obj.Visible = False Then
                        temp_LA.Hide()
                        temp_LA.Width = 15
                        temp_LA.Height = 15

                        enemy_Obj.子弹是否拼撞 = False
                        temp_time.Enabled = False

                        Exit Sub


                    End If

                    '这里###############
                    If Label1.Left = enemy_Obj.Left And Label1.Top = enemy_Obj.Top - 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub
                    End If


                    If Label1.Left = enemy_Obj.Left + 30 And Label1.Top = enemy_Obj.Top - 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub



                    End If


                    If Label1.Left = enemy_Obj.Left - 30 And Label1.Top = enemy_Obj.Top - 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub
                    End If








                    If m_map((tempY - 30) \ H, tempX \ W) = -1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub


                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        temp_LA.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1
                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1

                        ClearSelectedBlock(tempX, tempY - H, g)
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1


                        ClearSelectedBlock(tempX, tempY - H, g)
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY - H)

                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1

                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -2 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -2 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub


                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 2 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 2 Then



                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 2 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -1 Then



                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 2 Then



                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 2 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        temp_LA.Location = New Point(tempX + 15, tempY)
                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        beginGame()
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 2 Then
                        Dim g As Graphics = get_Graphic()

                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY)
                        m_map((tempY - 30) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 3 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 3 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 3 And m_map((tempY - 30) \ H, (tempX + W) \ W) = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = -1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 3 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY - 15)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        Exit Sub

                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 1 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY - H)
                        m_map((tempY - 30) \ H, tempX \ W) = -1
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType

                        ClearSelectedBlock(tempX, tempY - H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    ElseIf m_map((tempY - 30) \ H, tempX \ W) = 3 And m_map((tempY - 30) \ H, (tempX + W) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY - H)

                        m_map((tempY - 30) \ H, (tempX + W) \ W) = -1

                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                        ClearSelectedBlock(tempX + W, tempY - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    End If



                Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_DownType
                    '向下子弹未发射##################################################################################

                    If tempY >= PictureBox1.Height - 60 Then

                        '当坦克的Y等于PictureBox1.height时，就是最下方了
                        temp_LA.Visible = True
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 60 \ 2 - 14, PictureBox1.Height - 10)

                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If
                    If enemy_Obj.Visible = False Then
                        temp_LA.Hide()
                        temp_LA.Width = 15
                        temp_LA.Height = 15

                        enemy_Obj.子弹是否拼撞 = False
                        temp_time.Enabled = False

                        Exit Sub



                    End If



                    '这里########################
                    If Label1.Left = enemy_Obj.Left And Label1.Top = enemy_Obj.Top + 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX + 15, tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub
                    End If

                    If Label1.Left = enemy_Obj.Left + 30 And Label1.Top = enemy_Obj.Top + 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX + 15, tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub



                    End If

                    If Label1.Left = enemy_Obj.Left - 30 And Label1.Top = enemy_Obj.Top + 60 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX + 15, tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If










                    Dim LA_ONE_DOWN_m_map_1 As Integer = m_map((tempY + 60) \ H, tempX \ W)
                    Dim LA_ONE_DOWN_m_map_2 As Integer = m_map((tempY + 60) \ H, (tempX + 30) \ W)


                    If LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1

                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1



                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)



                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = -2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub
                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = -2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1



                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -2 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)



                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = 3 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 3 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + 22), tempY + 60)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1



                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 3 And LA_ONE_DOWN_m_map_2 = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 22, tempY + LA_ONE_H + H)



                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1


                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = 2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = -1 And LA_ONE_DOWN_m_map_2 = 2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_ONE_DOWN_m_map_1 = 2 And LA_ONE_DOWN_m_map_2 = 1 Then
                        Dim g As Graphics = get_Graphic()


                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        m_map((tempY + LA_ONE_H) \ H, (tempX + W) \ W) = -1
                        ClearSelectedBlock(tempX + W, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_ONE_DOWN_m_map_1 = 1 And LA_ONE_DOWN_m_map_2 = 2 Then
                        Dim g As Graphics = get_Graphic()


                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + 15, tempY + LA_ONE_H)

                        m_map((tempY + LA_ONE_H) \ H, tempX \ W) = -1
                        ClearSelectedBlock(tempX, tempY + LA_ONE_H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    End If
                Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_LeftType
                    '向左未发射####################################################################################

                    If tempX <= 0 Then
                        temp_LA.Visible = True

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 3, tempY + 15)
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType

                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If

                    If enemy_Obj.Visible = False Then
                        temp_LA.Hide()
                        temp_LA.Width = 15
                        temp_LA.Height = 15

                        enemy_Obj.子弹是否拼撞 = False
                        temp_time.Enabled = False

                        Exit Sub
                    End If

                    '这里####################
                    If Label1.Left = enemy_Obj.Left - 60 And Label1.Top = enemy_Obj.Top Then



                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub





                    End If


                    If Label1.Left = enemy_Obj.Left - 60 And Label1.Top = enemy_Obj.Top + 30 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub



                    End If

                    If Label1.Left = enemy_Obj.Left - 60 And Label1.Top = enemy_Obj.Top - 30 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If








                    Dim left_m_map_one As Integer = m_map(tempY \ H, (tempX - W) \ W)
                    Dim left_m_map_two As Integer = m_map((tempY + H) \ H, (tempX - W) \ W)

                    If m_map(tempY \ H, (tempX - W) \ W) = -1 And m_map((tempY + H) \ H, (tempX - W) \ W) = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1
                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1

                        ClearSelectedBlock(tempX - W, tempY, g)
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf left_m_map_one = 1 And left_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf left_m_map_one = -1 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = -2 And m_map((tempY + H) \ H, (tempX - W) \ W) = -2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = -2 And m_map((tempY + H) \ H, (tempX - W) \ W) = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = -1 And m_map((tempY + H) \ H, (tempX - W) \ W) = -2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf left_m_map_one = 1 And left_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf left_m_map_one = -2 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = 3 And m_map((tempY + H) \ H, (tempX - W) \ W) = 3 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = 3 And m_map((tempY + H) \ H, (tempX - W) \ W) = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub

                    ElseIf m_map(tempY \ H, (tempX - W) \ W) = -1 And m_map((tempY + H) \ H, (tempX - W) \ W) = 3 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX - LA2_W), tempY + 22) 'LA2_W =15

                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                        Exit Sub



                    ElseIf left_m_map_one = 1 And left_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf left_m_map_one = 3 And left_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 15, tempY + 22)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf left_m_map_one = 2 And left_m_map_two = 2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX - 5, tempY + 15)


                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf left_m_map_one = 2 And left_m_map_two = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX - 5, tempY + 15)


                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf left_m_map_one = -1 And left_m_map_two = 2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(tempX - 5, tempY + 15)


                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf left_m_map_one = 2 And left_m_map_two = 1 Then
                        Dim g As Graphics = get_Graphic()


                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 5, tempY + 15)

                        m_map((tempY + H) \ H, (tempX - W) \ W) = -1
                        ClearSelectedBlock(tempX - W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf left_m_map_one = 1 And left_m_map_two = 2 Then
                        Dim g As Graphics = get_Graphic()


                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX - 5, tempY + 15)
                        m_map(tempY \ H, (tempX - W) \ W) = -1


                        ClearSelectedBlock(tempX - W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    End If

                Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_RightType
                    '向右子弹未发射##############################################################

                    If tempX >= PictureBox1.Width - 60 Then
                        temp_LA.Visible = True

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(PictureBox1.Width - LA2_W, tempY + 15)
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType

                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If


                    If enemy_Obj.Visible = False Then
                        temp_LA.Hide()
                        temp_LA.Width = 15
                        temp_LA.Height = 15

                        enemy_Obj.子弹是否拼撞 = False
                        temp_time.Enabled = False

                        Exit Sub



                    End If

                    '这里##################

                    If Label1.Left = enemy_Obj.Left + 60 And Label1.Top = enemy_Obj.Top Then


                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub


                    End If



                    If Label1.Left = enemy_Obj.Left + 60 And Label1.Top = enemy_Obj.Top + 30 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If


                    If Label1.Left = enemy_Obj.Left + 60 And Label1.Top = enemy_Obj.Top - 30 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True



                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If





















                    Dim LA_TWO_m_map_one As Integer = m_map(tempY \ H, (tempX + 60) \ W)
                    Dim LA_TWO_m_map_two As Integer = m_map((tempY + H) \ H, (tempX + 60) \ W)






                    If m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1 And m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1
                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1

                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)
                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = -2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = -2 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = -2 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = 3 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = -1 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 3 Then
                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If
                        temp_LA.Image = bullet_image
                        temp_LA.Location = New Point((tempX + LA_ONE_W), tempY + 22)
                        enemy_Obj.子弹是否第一次发射 = False
                        enemy_Obj.E_BUT_TYPE_Direction = EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)

                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 3 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = 2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = -1 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = -1 And LA_TWO_m_map_two = 2 Then

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 15)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 2 And LA_TWO_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map((tempY + H) \ H, (tempX + LA_ONE_W) \ W) = -1


                        ClearSelectedBlock(tempX + LA_ONE_W, tempY + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_TWO_m_map_one = 1 And LA_TWO_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        If temp_LA.Visible = False Then
                            temp_LA.Visible = True
                        End If


                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(tempX + LA_ONE_W, tempY + 7)


                        m_map(tempY \ H, (tempX + LA_ONE_W) \ W) = -1

                        ClearSelectedBlock(tempX + LA_ONE_W, tempY, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub





                    End If


                Case Else
                    temp_time.Enabled = False
                    Exit Sub
            End Select



            '以下是子弹已经发射向上，只判断子弹的坐标############################################################
            '以下是子弹已经发射，只判断子弹的坐标############################################################
            '以下是子弹已经发射，只判断子弹的坐标############################################################
        Else

            temp_LA.Width = 15
            temp_LA.Height = 15
            Select Case enemy_Obj.E_BUT_TYPE_Direction
                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_UpType
                    Dim L2_x As Integer = temp_LA.Left
                    Dim L2_y As Integer = temp_LA.Top

                    If L2_y <= 30 Then
                        '当Y=30时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point((L2_x - 10), 0)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If


                    '这里#########################
                    If Label1.Left = temp_LA.Left - 22 And Label1.Top = temp_LA.Top - 75 Then
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top - 15)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub




                    End If

                    If Label1.Left = temp_LA.Left - 22 - 30 And Label1.Top = temp_LA.Top - 75 Then
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top - 15)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If
                    If Label1.Left = temp_LA.Left + 8 And Label1.Top = temp_LA.Top - 75 Then
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top - 15)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub




                    End If





                    '当子弹正常飞行时，每次向上加30高________________
                    If m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub


                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1
                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1

                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)
                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left - 12, temp_LA.Top)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left - 12, temp_LA.Top)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left - 12, temp_LA.Top)

                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left - 12, temp_LA.Top)
                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 2 Then
                        Dim g As Graphics = get_Graphic()


                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left - 12, temp_LA.Top)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1
                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub


                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_x, L2_y - H)
                        Exit Sub


                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 3 Then
                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)
                        m_map((L2_y - H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y - H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y - H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y - H) \ H, (L2_x + 23) \ W) = 1 Then
                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(temp_LA.Left, temp_LA.Top - H)

                        m_map((L2_y - H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y - H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    End If



                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_DownType
                    '向下子弹已发射##################################################################################
                    Dim L2_x As Integer = temp_LA.Left
                    Dim L2_y As Integer = temp_LA.Top

                    If L2_y >= PictureBox1.Height - H Then
                        '当子弹在最下边界，时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point((L2_x - 10), PictureBox1.Height - 5)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If

                    '这里############################

                    If Label1.Left = temp_LA.Left - 22 And Label1.Top = temp_LA.Top + 30 Then
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top + 30)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub
                    End If

                    If Label1.Left = temp_LA.Left - 22 - 30 And Label1.Top = temp_LA.Top + 30 Then
                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top + 30)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub







                    End If
                    If Label1.Left = temp_LA.Left + 8 And Label1.Top = temp_LA.Top + 30 Then

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left - 7, temp_LA.Top + 30)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub





                    End If



                   





                    If m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1
                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1

                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)


                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)


                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_x, L2_y + H)
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 3 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)

                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1


                        ClearSelectedBlock(L2_x - 22, L2_y + H, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 3 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x, L2_y + H)


                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1


                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then



                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 2 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        m_map((L2_y + H) \ H, (L2_x + 23) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_y + H) \ H, (L2_x - 22) \ W) = 1 And m_map((L2_y + H) \ H, (L2_x + 23) \ W) = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 30
                        temp_LA.Height = 15
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x - 12, L2_y + LA2_H)
                        m_map((L2_y + H) \ H, (L2_x - 22) \ W) = -1
                        ClearSelectedBlock(L2_x + 23, L2_y + H, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    End If



                  






                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_LeftType
                    '子弹已发射向左###################################################

                    Dim L2_X As Integer = temp_LA.Left
                    Dim L2_Y As Integer = temp_LA.Top
                    If L2_X <= 0 Then
                        '当子弹在最下边界，时就是讲，子弹已经到边上了，做好清除子弹的准备!
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(0, L2_Y - 5)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub
                    End If

                    '这里########################################
                    If Label1.Left = temp_LA.Left - 75 And Label1.Top = temp_LA.Top - 22 Then
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 15, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub


                    End If


                    If Label1.Left = temp_LA.Left - 75 And Label1.Top = temp_LA.Top - 22 - 30 Then

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 15, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub


                    End If

                    If Label1.Left = temp_LA.Left - 75 And Label1.Top = temp_LA.Top + 8 Then
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 15, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True



                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub

                    End If















                    Dim L2_LEFT_m_map_one = m_map((L2_Y - 22) \ H, (L2_X - 30) \ W)
                    Dim L2_LEFT_m_map_two = m_map((L2_Y + 8) \ H, (L2_X - 30) \ W)

                    If m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1
                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1

                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)
                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -2 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub



                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -2 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub

                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -2 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = -2 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = 3 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub



                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = 3 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub

                    ElseIf m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1 And m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = 3 Then
                        temp_LA.Location = New Point(L2_X - W, L2_Y)
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = 3 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)


                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf L2_LEFT_m_map_one = -1 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf L2_LEFT_m_map_one = 2 And L2_LEFT_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)

                        m_map((L2_Y + 8) \ H, (L2_X - 30) \ W) = -1
                        ClearSelectedBlock(L2_X - 30, L2_Y + 8, g)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf L2_LEFT_m_map_one = 1 And L2_LEFT_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_X - 15, L2_Y - 7)
                        m_map((L2_Y - 22) \ H, (L2_X - 30) \ W) = -1


                        ClearSelectedBlock(L2_X - 30, L2_Y - 22, g)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    End If

                Case EnemyTank_Class.E_BUT_DirectionType.Enemy_BUT_RightType
                    '子弹向右已发射###################################################################

                    Dim L2_x As Integer = temp_LA.Left
                    Dim L2_y As Integer = temp_LA.Top

                    If L2_x >= PictureBox1.Width - 30 Then
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(PictureBox1.Width - LA2_W, L2_y - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    End If
                    '这里#############
                    If Label1.Left = temp_LA.Left + 30 And Label1.Top = temp_LA.Top - 22 Then
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 30, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True



                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub
                    End If

                    If Label1.Left = temp_LA.Left + 30 And Label1.Top = temp_LA.Top - 22 - 30 Then
                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 30, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True


                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub



                    End If
                    If Label1.Left = temp_LA.Left + 30 And Label1.Top = temp_LA.Top + 8 Then

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image
                        temp_LA.Location = New Point(temp_LA.Left + 30, temp_LA.Top - 7)
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True

                        主机是否炸毁 = True
                        Timer3.Stop()
                        Timer3.Enabled = False
                        PictureBox6.Location = New Point(Label1.Left - 10, Label1.Top - 10)
                        Label1.Hide()
                        Label1.Location = New Point(-90, -90)
                        Timer16.Enabled = True
                        Exit Sub



                    End If





                    Dim LA_right_m_map_one As Integer = m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W)
                    Dim LA_right_m_map_two As Integer = m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W)


                    If m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1 And m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub



                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1
                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1

                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)
                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = -2 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub
                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = -1 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = -2 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub


                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = -2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = -2 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub




                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = 3 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub
                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = -1 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub

                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 3 Then

                        temp_LA.Location = New Point(L2_x + W, L2_y)
                        Exit Sub


                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 3 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)

                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = 3 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 30, L2_y - 7)


                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)
                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub

                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = -1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub


                    ElseIf LA_right_m_map_one = -1 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        Refresh() '这里可能会出错————————————————————————————

                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = 2 And LA_right_m_map_two = 1 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)

                        m_map((L2_y + 8) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y + 8, g)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub



                    ElseIf LA_right_m_map_one = 1 And LA_right_m_map_two = 2 Then

                        Dim g As Graphics = get_Graphic()

                        temp_LA.Width = 15
                        temp_LA.Height = 30
                        temp_LA.Image = bullet2_image

                        temp_LA.Location = New Point(L2_x + LA2_W + 7, L2_y - 7)
                        m_map((L2_y - 22) \ H, (L2_x + 15 + 30) \ W) = -1


                        ClearSelectedBlock(L2_x + 15 + 30, L2_y - 22, g)


                        beginGame()
                        enemy_Obj.子弹是否第一次发射 = True
                        enemy_Obj.子弹是否拼撞 = True
                        Exit Sub







                    End If

            End Select







        End If





    End Sub



    Private Sub Timer5_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer5.Tick
        敌方子弹(enemy_tank(0), Timer5, Label4)
    End Sub



    Public Sub 敌方坦克移动和发射(ByVal enemy_OJBLER2 As EnemyTank_Class, ByVal 敌方子弹_time As Timer, ByVal 本_time As Timer)
        Dim tempX As Integer = enemy_OJBLER2.Left
        Dim tempY As Integer = enemy_OJBLER2.Top

        If 敌方子弹_time.Enabled = False Then
            Dim ddr As New Random()
            If ddr.Next(1, 3) = 1 Then
                敌方子弹_time.Enabled = True
            End If





        End If



        If enemy_OJBLER2.only_oneBoolen = True Then
            '令AI方法只执行一次反回，0，1，2

            If enemy_AI(enemy_OJBLER2, 本_time) = False Then
                '执行一次就设为假不执行
                enemy_OJBLER2.only_oneBoolen = True

                Exit Sub
            Else


                enemy_OJBLER2.only_oneBoolen = False


            End If
        End If




        Select Case enemy_OJBLER2.E_TYPE


            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_LeftType
                '当方向是左边时###############################################################

                If tempX = 0 Then
                    '
                    enemy_OJBLER2.only_oneBoolen = True

                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If

                For i = 0 To 3
                    If enemy_tank(i).Equals(enemy_OJBLER2) = False Then
                        If enemy_tank(i).Left = enemy_OJBLER2.Left - 60 And enemy_tank(i).Top = enemy_OJBLER2.Top Then
                            enemy_OJBLER2.only_oneBoolen = True

                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = enemy_OJBLER2.Left - 60 And enemy_tank(i).Top = enemy_OJBLER2.Top + 30 Then

                            enemy_OJBLER2.only_oneBoolen = True

                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = enemy_OJBLER2.Left - 60 And enemy_tank(i).Top = enemy_OJBLER2.Top - 30 Then
                            enemy_OJBLER2.only_oneBoolen = True

                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If




                    End If

                Next


                If Label1.Left = enemy_OJBLER2.Left - 60 And Label1.Top = enemy_OJBLER2.Top Then
                    enemy_OJBLER2.only_oneBoolen = True

                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
                If Label1.Left = enemy_OJBLER2.Left - 60 And Label1.Top = enemy_OJBLER2.Top + 30 Then

                    enemy_OJBLER2.only_oneBoolen = True

                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
                If Label1.Left = enemy_OJBLER2.Left - 60 And Label1.Top = enemy_OJBLER2.Top - 30 Then
                    enemy_OJBLER2.only_oneBoolen = True

                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
















                If enemy_OJBLER2.e_direction = 1 Then
                    If is_left(tempX, tempY, enemy_OJBLER2) = False Then

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0
                    Else
                        Exit Sub
                    End If

                ElseIf enemy_OJBLER2.e_direction = 2 Then

                    If enemy_OJBLER2.em_rt_count <> 0 Then
                        enemy_OJBLER2.em_rt_count = enemy_OJBLER2.em_rt_count - 1

                        If is_left(tempX, tempY, enemy_OJBLER2) = False Then
                            Dim rrt As New Random
                            enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                            enemy_OJBLER2.only_oneBoolen = True


                        Else
                            Exit Sub
                        End If
                    Else
                        Dim rrt As New Random
                        enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0



                    End If


                End If


            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_RightType
                If tempX >= PictureBox1.Width - enemy_OJBLER2.Width Then

                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub

                End If

                For i = 0 To 3
                    If enemy_tank(i).Equals(enemy_OJBLER2) = False Then
                        If enemy_tank(i).Left = enemy_OJBLER2.Left + 60 And enemy_tank(i).Top = enemy_OJBLER2.Top Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = enemy_OJBLER2.Left + 60 And enemy_tank(i).Top = enemy_OJBLER2.Top + 30 Then

                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = enemy_OJBLER2.Left + 60 And enemy_tank(i).Top = enemy_OJBLER2.Top - 30 Then

                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If




                    End If

                Next


                If Label1.Left = enemy_OJBLER2.Left + 60 And Label1.Top = enemy_OJBLER2.Top Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If

                If Label1.Left = enemy_OJBLER2.Left + 60 And Label1.Top = enemy_OJBLER2.Top + 30 Then

                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
                If Label1.Left = enemy_OJBLER2.Left + 60 And Label1.Top = enemy_OJBLER2.Top - 30 Then

                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If















                If enemy_OJBLER2.e_direction = 1 Then
                    If is_right(tempX, tempY, enemy_OJBLER2) = False Then

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0
                    Else
                        Exit Sub
                    End If

                ElseIf enemy_OJBLER2.e_direction = 2 Then

                    If enemy_OJBLER2.em_rt_count <> 0 Then
                        enemy_OJBLER2.em_rt_count = enemy_OJBLER2.em_rt_count - 1

                        If is_right(tempX, tempY, enemy_OJBLER2) = False Then
                            Dim rrt As New Random
                            enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                            enemy_OJBLER2.only_oneBoolen = True


                        Else
                            Exit Sub
                        End If
                    Else
                        Dim rrt As New Random
                        enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0



                    End If


                End If



            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_UpType
                If tempY = 0 Then

                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub


                End If
                For i = 0 To 3
                    If enemy_tank(i).Equals(enemy_OJBLER2) = False Then
                        If enemy_tank(i).Left = enemy_OJBLER2.Left And enemy_tank(i).Top = enemy_OJBLER2.Top - 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If


                        If enemy_tank(i).Left = enemy_OJBLER2.Left + 30 And enemy_tank(i).Top = enemy_OJBLER2.Top - 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If

                        If enemy_tank(i).Left = enemy_OJBLER2.Left - 30 And enemy_tank(i).Top = enemy_OJBLER2.Top - 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If





                    End If

                Next


                If Label1.Left = enemy_OJBLER2.Left And Label1.Top = enemy_OJBLER2.Top - 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If


                If Label1.Left = enemy_OJBLER2.Left + 30 And Label1.Top = enemy_OJBLER2.Top - 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If

                If Label1.Left = enemy_OJBLER2.Left - 30 And Label1.Top = enemy_OJBLER2.Top - 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If













                If enemy_OJBLER2.e_direction = 1 Then
                    If is_up(tempX, tempY, enemy_OJBLER2) = False Then

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0
                    Else
                        Exit Sub
                    End If

                ElseIf enemy_OJBLER2.e_direction = 2 Then

                    If enemy_OJBLER2.em_rt_count <> 0 Then
                        enemy_OJBLER2.em_rt_count = enemy_OJBLER2.em_rt_count - 1

                        If is_up(tempX, tempY, enemy_OJBLER2) = False Then
                            Dim rrt As New Random
                            enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                            enemy_OJBLER2.only_oneBoolen = True


                        Else
                            Exit Sub
                        End If
                    Else
                        Dim rrt As New Random
                        enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0



                    End If


                End If



            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_DownType
                If tempY >= (PictureBox1.Height - enemy_OJBLER2.Height) Then

                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub

                End If
                For i = 0 To 3
                    If enemy_tank(i).Equals(enemy_OJBLER2) = False Then
                        If enemy_tank(i).Left = enemy_OJBLER2.Left And enemy_tank(i).Top = enemy_OJBLER2.Top + 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = enemy_OJBLER2.Left + 30 And enemy_tank(i).Top = enemy_OJBLER2.Top + 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If
                        If enemy_tank(i).Left = enemy_OJBLER2.Left - 30 And enemy_tank(i).Top = enemy_OJBLER2.Top + 60 Then
                            enemy_OJBLER2.only_oneBoolen = True
                            enemy_OJBLER2.e_direction = 0
                            Exit Sub
                        End If




                    End If

                Next


                If Label1.Left = enemy_OJBLER2.Left And Label1.Top = enemy_OJBLER2.Top + 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
                If Label1.Left = enemy_OJBLER2.Left + 30 And Label1.Top = enemy_OJBLER2.Top + 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
                If Label1.Left = enemy_OJBLER2.Left - 30 And Label1.Top = enemy_OJBLER2.Top + 60 Then
                    enemy_OJBLER2.only_oneBoolen = True
                    enemy_OJBLER2.e_direction = 0
                    Exit Sub
                End If
















                If enemy_OJBLER2.e_direction = 1 Then
                    If is_down(tempX, tempY, enemy_OJBLER2) = False Then

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0
                    Else
                        Exit Sub
                    End If

                ElseIf enemy_OJBLER2.e_direction = 2 Then

                    If enemy_OJBLER2.em_rt_count <> 0 Then
                        enemy_OJBLER2.em_rt_count = enemy_OJBLER2.em_rt_count - 1

                        If is_down(tempX, tempY, enemy_OJBLER2) = False Then
                            Dim rrt As New Random
                            enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                            enemy_OJBLER2.only_oneBoolen = True


                        Else

                            Exit Sub
                        End If
                    Else
                        Dim rrt As New Random
                        enemy_OJBLER2.em_rt_count = rrt.Next(1, 11)

                        enemy_OJBLER2.only_oneBoolen = True
                        enemy_OJBLER2.e_direction = 0



                    End If


                End If



        End Select




    End Sub
















    Private Sub Timer6_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer6.Tick
        敌方坦克移动和发射(enemy_tank(1), Timer7, Timer6)
    End Sub

    Private Sub Timer7_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer7.Tick
        敌方子弹(enemy_tank(1), Timer7, Label5)
    End Sub

    Private Sub Timer8_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer8.Tick
        敌方坦克移动和发射(enemy_tank(2), Timer9, Timer8)
    End Sub

    Private Sub Timer9_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer9.Tick
        敌方子弹(enemy_tank(2), Timer9, Label6)
    End Sub



    Private Sub Timer10_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer10.Tick
        敌方坦克移动和发射(enemy_tank(3), Timer11, Timer10)
    End Sub

    Private Sub Timer11_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer11.Tick
        敌方子弹(enemy_tank(3), Timer11, Label7)
    End Sub





    
    Private Sub Timer12_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer12.Tick

        Dim R_T As New Random()
        Select Case enemy_tank(0).敌机炸图片加载次数
            Case 0
                PictureBox2.Width = 80
                PictureBox2.Height = 80
                PictureBox2.Image = enemy_boom_image1
                PictureBox2.Visible = True

            Case 1
                PictureBox2.Image = enemy_boom_image2
            Case 2
                PictureBox2.Image = enemy_boom_image3
            Case 3
                PictureBox2.Hide()
                Timer12.Interval = 1000 '##########################


            Case 4
                PictureBox2.Width = 60
                PictureBox2.Height = 60
                PictureBox2.Location = New Point(R_T.Next(0, 4) * 300, 0)
                PictureBox2.Image = born1_image
                PictureBox2.Visible = True

                Timer12.Interval = 250 '##########################







            Case 5

                PictureBox2.Image = born2_image




            Case 6
                PictureBox2.Image = born3_image



            Case 7
                PictureBox2.Image = born4_image

            Case 8
                PictureBox2.Hide()


                enemy_tank(0).Location = PictureBox2.Location
                enemy_tank(0).敌机炸后初始化()
                enemy_tank(0).Visible = True
                enemy_tank(0).Width = 60
                enemy_tank(0).Height = 60

                ' temp_picturt.Location = New Point(-100, -100)


                Timer4.Interval = 210

                Timer4.Enabled = True
                enemy_tank(0).敌机炸图片加载次数 = 0
                Timer12.Enabled = False
                Exit Sub

        End Select


        enemy_tank(0).敌机炸图片加载次数 = enemy_tank(0).敌机炸图片加载次数 + 1



    End Sub









    Private Sub Timer13_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer13.Tick

        Dim R_T As New Random()
        Select Case enemy_tank(1).敌机炸图片加载次数
            Case 0
                PictureBox3.Width = 80
                PictureBox3.Height = 80
                PictureBox3.Image = enemy_boom_image1
                PictureBox3.Visible = True

            Case 1
                PictureBox3.Image = enemy_boom_image2
            Case 2
                PictureBox3.Image = enemy_boom_image3
            Case 3
                PictureBox3.Hide()
                Timer13.Interval = 1000 '##########################


            Case 4
                PictureBox3.Width = 60
                PictureBox3.Height = 60
                PictureBox3.Location = New Point(R_T.Next(0, 4) * 300, 0)
                PictureBox3.Image = born1_image
                PictureBox3.Visible = True
                Timer13.Interval = 250 '##########################








            Case 5

                PictureBox3.Image = born2_image




            Case 6
                PictureBox3.Image = born3_image



            Case 7
                PictureBox3.Image = born4_image

            Case 8
                PictureBox3.Hide()


                enemy_tank(1).Location = PictureBox3.Location
                enemy_tank(1).敌机炸后初始化()
                enemy_tank(1).Visible = True
                enemy_tank(1).Width = 60
                enemy_tank(1).Height = 60

                ' temp_picturt.Location = New Point(-100, -100)


                Timer6.Interval = 210 '###############################

                Timer6.Enabled = True '###############################
                enemy_tank(1).敌机炸图片加载次数 = 0
                Timer13.Enabled = False '###############################
                Exit Sub

        End Select


        enemy_tank(1).敌机炸图片加载次数 = enemy_tank(1).敌机炸图片加载次数 + 1 '###############################


    End Sub

    Private Sub Timer14_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer14.Tick
        Dim R_T As New Random()
        Select Case enemy_tank(2).敌机炸图片加载次数
            Case 0
                PictureBox4.Width = 80
                PictureBox4.Height = 80
                PictureBox4.Image = enemy_boom_image1
                PictureBox4.Visible = True

            Case 1
                PictureBox4.Image = enemy_boom_image2
            Case 2
                PictureBox4.Image = enemy_boom_image3
            Case 3
                PictureBox4.Hide()
                Timer14.Interval = 1000 '##########################


            Case 4
                PictureBox4.Width = 60
                PictureBox4.Height = 60
                PictureBox4.Location = New Point(R_T.Next(0, 4) * 300, 0)
                PictureBox4.Image = born1_image
                PictureBox4.Visible = True
                Timer14.Interval = 250 '##########################








            Case 5

                PictureBox4.Image = born2_image




            Case 6
                PictureBox4.Image = born3_image



            Case 7
                PictureBox4.Image = born4_image

            Case 8
                PictureBox4.Hide()


                enemy_tank(2).Location = PictureBox4.Location
                enemy_tank(2).敌机炸后初始化()
                enemy_tank(2).Visible = True
                enemy_tank(2).Width = 60
                enemy_tank(2).Height = 60

                ' temp_picturt.Location = New Point(-100, -100)


                Timer8.Interval = 210 '###############################

                Timer8.Enabled = True '###############################
                enemy_tank(2).敌机炸图片加载次数 = 0
                Timer14.Enabled = False '###############################
                Exit Sub

        End Select


        enemy_tank(2).敌机炸图片加载次数 = enemy_tank(2).敌机炸图片加载次数 + 1 '###############################
    End Sub

    Private Sub Timer15_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer15.Tick
        Dim R_T As New Random()

        Select Case enemy_tank(3).敌机炸图片加载次数
            Case 0
                PictureBox5.Width = 80
                PictureBox5.Height = 80
                PictureBox5.Image = enemy_boom_image1
                PictureBox5.Visible = True

            Case 1
                PictureBox5.Image = enemy_boom_image2
            Case 2
                PictureBox5.Image = enemy_boom_image3
            Case 3
                PictureBox5.Hide()
                Timer15.Interval = 1000 '##########################


            Case 4
                PictureBox5.Width = 60
                PictureBox5.Height = 60
                PictureBox5.Location = New Point(R_T.Next(0, 4) * 300, 0)
                PictureBox5.Image = born1_image
                PictureBox5.Visible = True
                Timer15.Interval = 250 '##########################








            Case 5

                PictureBox5.Image = born2_image




            Case 6
                PictureBox5.Image = born3_image



            Case 7
                PictureBox5.Image = born4_image

            Case 8
                PictureBox5.Hide()


                enemy_tank(3).Location = PictureBox5.Location
                enemy_tank(3).敌机炸后初始化()
                enemy_tank(3).Visible = True
                enemy_tank(3).Width = 60
                enemy_tank(3).Height = 60

                ' temp_picturt.Location = New Point(-100, -100)


                Timer10.Interval = 210 '###############################

                Timer10.Enabled = True '###############################
                enemy_tank(3).敌机炸图片加载次数 = 0
                Timer15.Enabled = False '###############################
                Exit Sub

        End Select


        enemy_tank(3).敌机炸图片加载次数 = enemy_tank(3).敌机炸图片加载次数 + 1 '###############################
    End Sub

    Private Sub Timer16_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer16.Tick
        Select Case 加载炸图片主机
            Case 0
                PictureBox6.Width = 80
                PictureBox6.Height = 80
                PictureBox6.Image = enemy_boom_image1
                PictureBox6.Visible = True
            Case 1
                PictureBox6.Image = enemy_boom_image2
            Case 2
                PictureBox6.Image = enemy_boom_image3
            Case 3
                PictureBox6.Hide()
                Timer16.Interval = 800

            Case 4
                PictureBox6.Width = 60
                PictureBox6.Height = 60

                PictureBox6.Location = New Point(10 * 30, 20 * 30)
                PictureBox6.Image = born1_image
                PictureBox6.Visible = True
                Timer16.Interval = 250 '##########################

               
            Case 5

                PictureBox6.Image = born2_image




            Case 6
                PictureBox6.Image = born3_image



            Case 7
                PictureBox6.Image = born4_image

            Case 8
                PictureBox6.Hide()


                Label1.Location = PictureBox6.Location '初始化Lable1##############
                Label1.Image = up_image
                isOne = True
                isWall = False
                move_type = move_UpType.move_UpType
                主机是否炸毁 = False


                Label1.Width = 60
                Label1.Height = 60

                Label1.Visible = True
                


                Timer16.Interval = 150 '###############################

                Timer16.Enabled = False '###############################
                加载炸图片主机 = 0

                Exit Sub

        End Select

        加载炸图片主机 = 加载炸图片主机 + 1









    End Sub
End Class

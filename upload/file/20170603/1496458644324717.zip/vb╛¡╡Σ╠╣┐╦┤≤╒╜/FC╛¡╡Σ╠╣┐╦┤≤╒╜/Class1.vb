﻿Public Class EnemyTank_Class
    Inherits Label
    Public Ew_left_image, Ew_right_image, Ew_up_image, Ew_down_image As Image '各个敌机的图片
    Public Ey_left_image, Ey_right_image, Ey_up_image, Ey_down_image As Image
    Public Eg_left_image, Eg_right_image, Eg_up_image, Eg_down_image As Image
    Public Egt_left_image, Egt_right_image, Egt_up_image, Egt_down_image As Image

    Public EE_left_image, EE_rightT_image, EE_up_image, EE_down_image As Image
    Public isTimeSet As Boolean = False

    Public e_direction As Integer = 0 '用来表示敌机的AI
    Public only_oneBoolen As Boolean = True
    Public em_rt_count As Integer = 0

    Public rt_count As Integer
    Public 子弹是否拼撞 As Boolean = False
    Public 子弹是否第一次发射 As Boolean = True
    Public 敌机炸图片加载次数 As Integer = 0
    Public Enum EnemyTank_DirectionType
        EnemyTank_LeftType
        EnemyTank_RightType
        EnemyTank_UpType
        EnemyTank_DownType
    End Enum
    Public Enum E_BUT_DirectionType
        Enemy_BUT_LeftType
        Enemy_BUT_RightType
        Enemy_BUT_UpType
        Enemy_BUT_DownType
    End Enum



    Public E_TYPE As EnemyTank_DirectionType = EnemyTank_DirectionType.EnemyTank_DownType '敌方坦克的方向类型

    Public E_BUT_TYPE_Direction As E_BUT_DirectionType = E_BUT_DirectionType.Enemy_BUT_DownType '子弹的方向类型







    Public Sub New()
        Width = 60
        Height = 60
        BackColor = Color.Black

        Ew_left_image = My.Resources.Resource1.wl
        Ew_right_image = My.Resources.Resource1.wr
        Ew_up_image = My.Resources.Resource1.wu
        Ew_down_image = My.Resources.Resource1.wd

        Ey_left_image = My.Resources.Resource1.yellowL
        Ey_right_image = My.Resources.Resource1.yellowR
        Ey_up_image = My.Resources.Resource1.yellowU
        Ey_down_image = My.Resources.Resource1.yellowD

        Eg_left_image = My.Resources.Resource1.greenL
        Eg_right_image = My.Resources.Resource1.greenR
        Eg_up_image = My.Resources.Resource1.greenU
        Eg_down_image = My.Resources.Resource1.greenD

        Egt_left_image = My.Resources.Resource1.green2L
        Egt_right_image = My.Resources.Resource1.green2R
        Egt_up_image = My.Resources.Resource1.green2U
        Egt_down_image = My.Resources.Resource1.green2D

        Dim rt As New Random()


        Select Case rt.Next(1, 5)
            Case 1
                Image = Ew_down_image
                rt_count = 1
                EE_left_image = Ew_left_image
                EE_rightT_image = Ew_right_image
                EE_up_image = Ew_up_image
                EE_down_image = Ew_down_image

            Case 2
                Image = Ey_down_image
                rt_count = 2
                EE_left_image = Ey_left_image
                EE_rightT_image = Ey_right_image
                EE_up_image = Ey_up_image
                EE_down_image = Ey_down_image
            Case 3
                Image = Eg_down_image
                rt_count = 3
                EE_left_image = Eg_left_image
                EE_rightT_image = Eg_right_image
                EE_up_image = Eg_up_image
                EE_down_image = Eg_down_image


            Case 4
                Image = Egt_down_image
                rt_count = 4
                EE_left_image = Egt_left_image
                EE_rightT_image = Egt_right_image
                EE_up_image = Egt_up_image
                EE_down_image = Egt_down_image
        End Select
        Dim rrt As New Random
        em_rt_count = rrt.Next(1, 11)


    End Sub

    Public Sub 改变敌机图片()

        ' Image = Ew_down_image
        rt_count = 1
        EE_left_image = Ew_left_image
        EE_rightT_image = Ew_right_image
        EE_up_image = Ew_up_image
        EE_down_image = Ew_down_image
        Select Case Me.E_TYPE
            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_UpType
                Me.Image = Me.Ew_up_image
            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_DownType
                Me.Image = Me.Ew_down_image
            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_LeftType
                Me.Image = Me.Ew_left_image
            Case EnemyTank_Class.EnemyTank_DirectionType.EnemyTank_RightType
                Me.Image = Me.Ew_right_image

        End Select
       
    End Sub

    Public Sub 敌机炸后初始化()

        Dim rt As New Random()


        Select Case rt.Next(1, 5)
            Case 1
                Image = Ew_down_image
                rt_count = 1
                EE_left_image = Ew_left_image
                EE_rightT_image = Ew_right_image
                EE_up_image = Ew_up_image
                EE_down_image = Ew_down_image

            Case 2
                Image = Ey_down_image
                rt_count = 2
                EE_left_image = Ey_left_image
                EE_rightT_image = Ey_right_image
                EE_up_image = Ey_up_image
                EE_down_image = Ey_down_image
            Case 3
                Image = Eg_down_image
                rt_count = 3
                EE_left_image = Eg_left_image
                EE_rightT_image = Eg_right_image
                EE_up_image = Eg_up_image
                EE_down_image = Eg_down_image


            Case 4
                Image = Egt_down_image
                rt_count = 4
                EE_left_image = Egt_left_image
                EE_rightT_image = Egt_right_image
                EE_up_image = Egt_up_image
                EE_down_image = Egt_down_image
        End Select

        isTimeSet = False

        e_direction = 0 '用来表示敌机的AI
        only_oneBoolen = True
        Dim rrt As New Random
        em_rt_count = rrt.Next(1, 11)


        子弹是否拼撞 = False
        子弹是否第一次发射 = True
        E_TYPE = EnemyTank_DirectionType.EnemyTank_DownType
        E_BUT_TYPE_Direction = E_BUT_DirectionType.Enemy_BUT_DownType













    End Sub




End Class
